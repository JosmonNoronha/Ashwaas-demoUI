#!/bin/bash
GIT_BRANCH="release/7.0"
