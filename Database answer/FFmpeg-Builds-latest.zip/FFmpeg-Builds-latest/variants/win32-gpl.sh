#!/bin/bash
source "$(dirname "$BASH_SOURCE")"/windows-install-static.sh
source "$(dirname "$BASH_SOURCE")"/defaults-gpl.sh
